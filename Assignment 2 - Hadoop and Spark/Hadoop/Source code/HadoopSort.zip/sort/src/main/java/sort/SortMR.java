package sort;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class SortMR  extends Configured implements Tool
{
      public int run(String[] args) throws Exception
      {
            //getting configuration object and setting job name
            Configuration conf = getConf();
        
		Job job = new Job(conf, "sort job - "+ args[0]);

		//Set Classes
        job.setJarByClass(SortMR.class);

        job.setMapperClass(SortMapper.class);
        job.setReducerClass(SortReducer.class);
        
        job.setInputFormatClass(TextInputFormat.class);
        job.setOutputFormatClass(TextOutputFormat.class);
        
        //setting the output data type classes
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class); //setting output value to null
        job.setMapOutputValueClass(Text.class); //overriding the mapper output value to Text (reducer output value remains null
       
       
        //to accept the hdfs input and output dir at run time
        FileInputFormat.addInputPath(job, new Path(args[1])); //input directory
        FileOutputFormat.setOutputPath(job, new Path(args[2])); //output directory
        
        
return job.waitForCompletion(true) ? 0 : 1;
    }

    public static void main(String[] args) throws Exception {
        int res = ToolRunner.run(new Configuration(), new SortMR(), args);
        System.exit(res);
    }
}





