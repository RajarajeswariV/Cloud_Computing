package sort;

import java.io.IOException;
import java.util.Arrays;
import java.util.StringTokenizer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;

public class SortMapper extends Mapper<LongWritable, Text, Text, Text>
{
    private Text word = new Text();
       
         public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
         {
 //taking one line at a time and splitting the same based on "  "
        	 String fullString = value.toString();
        	 
        	 int strLen = fullString.length();

// Creates the key as first 10 bytes and pass the key (first 10bytes)
// along its values (remaining bytes) to the reducer for sorting based on the key.
        	 
        	if (strLen >10 ) {
        		strLen = 10;
        	}
        	 
        	 char [] charValue = new char[strLen];
        	 
        	 
        	 for (int j = 0; j< strLen; j++ ){
        		 charValue [j] = fullString.charAt(j);
        		 System.out.println("Char  " + charValue [j]);
        	 }
        	 
         	 String line = new String(charValue);

         	 System.out.println("char " + line);
        	 
             context.write(new Text(line), value); // writing the output key as the first 10 bytes , 
                                                      //value as whole record including 1st 10 bytes
           
         }
         
 }



